#!/usr/bin/env bash

# map_one_sample.sh
#
# Creates pileup files in .bed format for 4 Illumina samples

echo "Running single_process.sh..."

# Assign variables governing mapping
batch="A1"
read_length="31"

# Create output directories
echo "Setting up working area..."
./clean.sh
mkdir mappings pileups

# Create bwa index for genome
echo "Creating index for genome..."
bwa index genome/genome.fasta

# Align reads
echo "Mapping reads to genome..."
bwa aln genome/genome.fasta reads/$batch.fastq > mappings/$batch.sai
bwa samse genome/genome.fasta mappings/$batch.sai reads/$batch.fastq > mappings/$batch.sam

# Create pileup using samtools
echo "Creating pileup files..."
samtools view -bS mappings/$batch.sam > mappings/$batch.bam
samtools sort mappings/$batch.bam mappings/$batch.sorted
samtools index mappings/$batch.sorted.bam
samtools mpileup -f genome/genome.fasta mappings/$batch.sorted.bam > pileups/$batch.pileup

# Run custom script to convert pileup into bed file
echo "Converting pileup file to bed file..."
./code/pileup2bedfile.py pileups/$batch.pileup $read_length

echo "Moving bed files to bedfiles/..."
mv pileups/*.bed bedfiles/.

echo "Removing old files and directories..."
rm -rf mappings pileups
rm -f genome/genome.fastq.*

# We're all done!
echo "Done!"