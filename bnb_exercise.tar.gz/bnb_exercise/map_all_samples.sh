#!/usr/bin/env bash

# map_all_samples.sh
#
# Creates pileup files in .bed format for 4 Illumina samples

echo "Running single_process.sh..."

# Assign variables governing mapping
read_length="31"
wait_time="10s"

# Create output directories
echo "Setting up working area..."
./clean.sh
mkdir mappings pileups scripts

# Create bwa index for genome
echo "Creating index for genome..."
bwa index genome/genome.fasta

#
# Submit jobs for 4 samples to 4 different nodes
#
for batch in A1 B1 C1 D1;
do

	# Define name for script file
	script_file="scripts/map_$batch.sh"

	# Align reads
	echo """
	echo 'Aligning reads to genome...'
	bwa aln genome/genome.fasta reads/$batch.fastq > mappings/$batch.sai
	bwa samse genome/genome.fasta mappings/$batch.sai reads/$batch.fastq > mappings/$batch.sam
	samtools view -bS mappings/$batch.sam > mappings/$batch.bam


	echo 'Creating pileup files...'
	samtools sort mappings/$batch.bam mappings/$batch.sorted
	samtools index mappings/$batch.sorted.bam
	samtools mpileup -f genome/genome.fasta mappings/$batch.sorted.bam > pileups/$batch.pileup

	# Run custom script to convert pileup into bed file
	echo 'Converting pileup file to bed file...'
	./code/pileup2bedfile.py pileups/$batch.pileup $read_length

	echo 'Script done!'
	""" > $script_file
	chmod u+x $script_file

	# Submit scripts to cluster
	echo "Submitting $script_file to cluster..."
	qsub -cwd $script_file
done

echo "Waiting for scripts to finish ..."

# Compute the number of jobs left
num_jobs_left=`qstat | grep "map_" |  wc -l`

# As long as there are jobs left, wait 5 seconds then check again
while [ $num_jobs_left -gt 0 ]
do
	echo "-> $num_jobs_left jobs left. Waiting $wait_time..."
	sleep $wait_time
	num_jobs_left=`qstat | grep "map_" |  wc -l`
done

echo "Moving bed files to bedfiles/..."
mv pileups/*.bed bedfiles/.

echo "Removing old files and directories..."
rm -rf mappings pileups scripts
rm -f genome/genome.fastq.*
#rm -f *.sh.*

# We're all done!
echo "Done!"
